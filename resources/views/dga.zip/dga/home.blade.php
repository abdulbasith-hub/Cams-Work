<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="{{ $content['hero']['subtitle'] ?? 'Office of the Director General of Audit, Government of Tamil Nadu' }}">
    <meta name="theme-color" content="#0f4d7a">
    <title>Director General of Audit · Government of Tamil Nadu</title>
    <link rel="shortcut icon" type="image/png" href="{{ asset('site/image/tn__logo.png') }}">

    {{-- Typography --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@400;600;700&family=Source+Serif+4:opsz,wght@8..60,600;8..60,700&display=swap" rel="stylesheet">

    {{-- Bootstrap 5 + Icons --}}
    <link rel="stylesheet" href="{{ asset('assets/libs/bootstrap/dist/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/libs/bootstrap-icons/font/bootstrap-icons.min.css') }}">
    <link rel="stylesheet" href="{{ asset('site/css/dga-portal.css') }}">
</head>
<body class="dga-portal-body" id="dga-page-top">
    <a class="skip-link" href="#main-content">Skip to main content</a>

    @include('dga.partials.portal.header', [
        'departments' => $departments,
        'homeHref' => route('dga.home'),
    ])

    <main id="main-content">
        @include('dga.partials.portal.hero')
        @include('dga.partials.portal.announcements')
        @include('dga.partials.portal.services')
        @include('dga.partials.portal.updates')
        @include('dga.partials.portal.statistics')
        @include('dga.partials.portal.highlights')
        @include('dga.partials.portal.wings')
        @include('dga.partials.portal.modules')
        @include('dga.partials.portal.gallery')
        @include('dga.partials.portal.downloads')
        @include('dga.partials.portal.contact')
    </main>

    @include('dga.partials.portal.footer')

    <script src="{{ asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js') }}" defer></script>
    <script src="{{ asset('site/js/dga-portal.js') }}" defer></script>
</body>
</html>
