{{-- Announcements ticker — pauses on hover/focus for accessibility --}}
@if (!empty($content['announcements']))
<section id="announcements" class="dga-announce py-3" aria-label="Announcements">
    <div class="container">
        <div class="row align-items-center g-2 g-md-3">
            <div class="col-auto">
                <span class="dga-announce__label">
                    <i class="bi bi-megaphone-fill" aria-hidden="true"></i>
                    Announcements
                </span>
            </div>
            <div class="col min-w-0">
                <div class="dga-ticker" tabindex="0" aria-live="polite">
                    <div class="dga-ticker__track">
                        @foreach (array_merge($content['announcements'], $content['announcements']) as $index => $item)
                            <span class="dga-ticker__item" @if ($index >= count($content['announcements'])) aria-hidden="true" @endif>
                                {{ $item }}
                            </span>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endif
