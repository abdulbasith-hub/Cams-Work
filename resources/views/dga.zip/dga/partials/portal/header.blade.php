{{-- Portal sticky header: emblem, logo, search, language, login, hamburger nav --}}
@php
    $homeHref = $homeHref ?? route('dga.home');
@endphp

<div class="dga-topbar">
    <div class="container py-2">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div class="d-flex flex-wrap align-items-center gap-2" aria-label="Accessibility controls">
                <a href="{{ url('screenreader') }}" class="d-inline-flex align-items-center gap-1">
                    <i class="bi bi-volume-up" aria-hidden="true"></i>
                    <span>Screen Reader</span>
                </a>
                <div class="dga-font-controls" aria-label="Font size controls">
                    <button type="button" data-dga-font="decrease" aria-label="Decrease font size">A-</button>
                    <button type="button" data-dga-font="reset" aria-label="Reset font size">A</button>
                    <button type="button" data-dga-font="increase" aria-label="Increase font size">A+</button>
                </div>
            </div>
            <div class="dga-language-switch" aria-label="Language selector">
                <button type="button" data-dga-language="en" aria-pressed="true">English</button>
                <button type="button" data-dga-language="ta" aria-pressed="false">தமிழ்</button>
            </div>
        </div>
    </div>
</div>

<header class="dga-site-header">
    <nav class="navbar navbar-expand-lg dga-navbar py-2" aria-label="Primary navigation">
        <div class="container">
            <a class="dga-brand navbar-brand me-lg-3" href="{{ $homeHref }}">
                <img class="dga-brand__emblem" src="{{ asset('site/image/tn__logo.png') }}" width="52" height="52" alt="Tamil Nadu State Emblem">
                <img class="dga-brand__logo d-none d-sm-block" src="{{ asset('site/image/india-gov-logo.png') }}" width="52" height="52" alt="Government of India logo" loading="lazy">
                <div class="dga-brand__text">
                    <h1>Director General of Audit</h1>
                    <span>Government of Tamil Nadu · CAMS</span>
                </div>
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#dgaPrimaryNav"
                aria-controls="dgaPrimaryNav" aria-expanded="false" aria-label="Toggle navigation menu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="dgaPrimaryNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 mt-3 mt-lg-0">
                    <li class="nav-item"><a class="nav-link active" href="#hero">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="#updates">Updates</a></li>
                    <li class="nav-item"><a class="nav-link" href="#highlights">Highlights</a></li>
                    <li class="nav-item"><a class="nav-link" href="#gallery">Gallery</a></li>
                    <li class="nav-item"><a class="nav-link" href="#downloads">Downloads</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                </ul>

                <div class="d-flex flex-column flex-lg-row align-items-stretch align-items-lg-center gap-2 ms-lg-2">
                    <form class="dga-search-form" role="search" data-dga-search aria-label="Site search">
                        <label class="visually-hidden" for="dgaSiteSearch">Search this page</label>
                        <input id="dgaSiteSearch" class="form-control" type="search" name="q" placeholder="Search…" autocomplete="off">
                        <button class="btn btn-primary" type="submit" aria-label="Submit search">
                            <i class="bi bi-search" aria-hidden="true"></i>
                        </button>
                    </form>
                    <a class="btn btn-primary dga-btn-login" href="{{ url('/login') }}">
                        <i class="bi bi-box-arrow-in-right me-1" aria-hidden="true"></i>
                        Login
                    </a>
                </div>
            </div>
        </div>
    </nav>

    @if (!empty($departments))
        <div class="dga-dept-strip d-none d-lg-block">
            <div class="container">
                <nav class="nav flex-nowrap overflow-auto py-1" aria-label="Field directorates">
                    @foreach ($departments as $departmentItem)
                        <div class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                aria-expanded="false" id="dept-{{ $departmentItem['slug'] }}">
                                {{ $departmentItem['short_name'] }}
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="dept-{{ $departmentItem['slug'] }}">
                                <li><a class="dropdown-item" href="{{ route('dga.department', $departmentItem['slug']) }}">Home</a></li>
                                <li><a class="dropdown-item" href="{{ route('dga.department', $departmentItem['slug']) }}#structure">Structure</a></li>
                                <li><a class="dropdown-item" href="{{ route('dga.department', $departmentItem['slug']) }}#functions">Functions</a></li>
                                <li><a class="dropdown-item" href="{{ route('dga.department', $departmentItem['slug']) }}#contact">Contact</a></li>
                            </ul>
                        </div>
                    @endforeach
                </nav>
            </div>
        </div>
    @endif
</header>
