{{-- Downloads — document cards --}}
@if (!empty($content['downloads']))
<section id="downloads" class="dga-section" aria-labelledby="dga-downloads-title">
    <div class="container">
        <div class="mb-4 mb-lg-5">
            <span class="dga-section__eyebrow">Resources</span>
            <h2 id="dga-downloads-title" class="dga-section__title">Downloads</h2>
            <p class="dga-section__lead">Acts, rules, and guidance documents for officers and citizens.</p>
        </div>

        <div class="row row-cols-1 row-cols-md-2 g-3 g-lg-4">
            @foreach ($content['downloads'] as $doc)
                <div class="col">
                    <article class="dga-card dga-download-card">
                        <span class="dga-download-card__icon" aria-hidden="true">
                            <i class="bi bi-file-earmark-pdf-fill"></i>
                        </span>
                        <div class="dga-download-card__body">
                            <h3>{{ $doc['title'] }}</h3>
                            <p>{{ $doc['meta'] }}</p>
                            <a class="btn btn-sm btn-primary dga-btn-primary"
                               href="{{ $doc['href'] }}"
                               @if (($doc['href'] ?? '#') === '#') aria-disabled="true" tabindex="-1" @endif>
                                <i class="bi bi-download me-1" aria-hidden="true"></i>
                                Download
                            </a>
                        </div>
                    </article>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif
