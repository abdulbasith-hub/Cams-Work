{{-- Hero: welcome, description, CTAs, responsive banner --}}
<section id="hero" class="dga-hero" aria-labelledby="dga-hero-title">
    <div class="container">
        <div class="row align-items-center g-4 g-xl-5">
            <div class="col-lg-6">
                <p class="mb-2 fw-bold text-uppercase" style="letter-spacing:0.08em;font-size:0.75rem;opacity:0.9;">
                    {{ $content['hero']['eyebrow'] ?? 'Government of Tamil Nadu' }}
                </p>
                <h2 id="dga-hero-title" class="dga-hero__title">{{ $content['hero']['title'] }}</h2>
                <p class="dga-hero__text">{{ $content['hero']['subtitle'] }}</p>
                <div class="d-flex flex-wrap gap-2">
                    <a class="btn btn-light fw-bold px-4 rounded-pill" href="#services">Explore Services</a>
                    <a class="btn btn-outline-light fw-bold px-4 rounded-pill" href="{{ url('/login') }}">CAMS Login</a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="dga-hero__media">
                    <img src="{{ asset('assets/images/cam.jpg') }}"
                         alt="Comprehensive Audit Management System visual"
                         width="960" height="600"
                         fetchpriority="high"
                         decoding="async">
                </div>
            </div>
        </div>
    </div>
</section>
