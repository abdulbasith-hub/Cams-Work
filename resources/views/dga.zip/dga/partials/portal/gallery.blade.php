{{-- Gallery with Bootstrap lightbox modal --}}
@if (!empty($content['gallery']))
<section id="gallery" class="dga-section dga-section--alt" aria-labelledby="dga-gallery-title">
    <div class="container">
        <div class="mb-4 mb-lg-5">
            <span class="dga-section__eyebrow">Visual Archive</span>
            <h2 id="dga-gallery-title" class="dga-section__title">Photo Gallery</h2>
            <p class="dga-section__lead">Select an image to open it in a larger, accessible lightbox view.</p>
        </div>

        <div class="dga-gallery" role="list">
            @foreach ($content['gallery'] as $index => $photo)
                <button type="button"
                        class="dga-gallery__item"
                        role="listitem"
                        data-dga-gallery-src="{{ asset($photo['src']) }}"
                        data-dga-gallery-alt="{{ $photo['alt'] }}"
                        aria-label="Open gallery image: {{ $photo['alt'] }}">
                    <img src="{{ asset($photo['src']) }}"
                         alt="{{ $photo['alt'] }}"
                         loading="lazy"
                         decoding="async"
                         width="480" height="360">
                </button>
            @endforeach
        </div>
    </div>
</section>

<div class="modal fade dga-lightbox" id="dgaGalleryLightbox" tabindex="-1"
     aria-labelledby="dgaGalleryLightboxLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <h2 class="modal-title h6 text-white" id="dgaGalleryLightboxLabel">
                    <span data-dga-lightbox-caption></span>
                </h2>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close gallery"></button>
            </div>
            <div class="modal-body pt-2">
                <img data-dga-lightbox-img src="" alt="">
            </div>
        </div>
    </div>
</div>
@endif
