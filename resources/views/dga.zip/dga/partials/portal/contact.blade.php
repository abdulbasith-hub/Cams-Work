{{-- Contact + map --}}
@php($contact = $content['contact'] ?? [])
<section id="contact" class="dga-section dga-section--alt" aria-labelledby="dga-contact-title">
    <div class="container">
        <div class="mb-4 mb-lg-5">
            <span class="dga-section__eyebrow">Reach Us</span>
            <h2 id="dga-contact-title" class="dga-section__title">Contact</h2>
            <p class="dga-section__lead">Office address, phone, email, and map for the Director General of Audit.</p>
        </div>

        <div class="row g-4 align-items-stretch">
            <div class="col-lg-5">
                <div class="dga-card dga-contact-card h-100">
                    <h3 class="h5 fw-bold mb-3">{{ $contact['office'] ?? 'Office of the Director General of Audit' }}</h3>
                    <ul class="dga-contact-list">
                        <li>
                            <i class="bi bi-geo-alt-fill" aria-hidden="true"></i>
                            <div>
                                <strong class="d-block">Address</strong>
                                <span>{{ $contact['address'] ?? '' }}</span>
                            </div>
                        </li>
                        <li>
                            <i class="bi bi-telephone-fill" aria-hidden="true"></i>
                            <div>
                                <strong class="d-block">Phone</strong>
                                <a href="tel:{{ preg_replace('/\s+/', '', $contact['phone'] ?? '') }}">{{ $contact['phone'] ?? '' }}</a>
                            </div>
                        </li>
                        <li>
                            <i class="bi bi-envelope-fill" aria-hidden="true"></i>
                            <div>
                                <strong class="d-block">Email</strong>
                                <a href="mailto:{{ $contact['email'] ?? '' }}">{{ $contact['email'] ?? '' }}</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="ratio ratio-16x9 h-100" style="min-height:18rem;">
                    <iframe class="dga-map-frame"
                            title="Google Map — Office of the Director General of Audit, Nandanam, Chennai"
                            src="{{ $contact['map_embed'] ?? '' }}"
                            loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"
                            allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</section>
