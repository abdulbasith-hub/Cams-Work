{{-- CAMS modules --}}
@if (!empty($content['modules']))
<section id="modules" class="dga-section" aria-labelledby="dga-modules-title">
    <div class="container">
        <div class="mb-4 mb-lg-5">
            <span class="dga-section__eyebrow">CAMS Platform</span>
            <h2 id="dga-modules-title" class="dga-section__title">Digital Modules</h2>
            <p class="dga-section__lead">Core modules powering planning, field audit, settlement, and performance review.</p>
        </div>

        <div class="row row-cols-1 row-cols-md-2 row-cols-xl-4 g-3 g-lg-4">
            @foreach ($content['modules'] as $module)
                <div class="col">
                    <article class="dga-card dga-module-card">
                        <h3>{{ $module['name'] }}</h3>
                        <ul>
                            @foreach ($module['points'] as $point)
                                <li>{{ $point }}</li>
                            @endforeach
                        </ul>
                    </article>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif
