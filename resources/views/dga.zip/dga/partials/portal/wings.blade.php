{{-- Functional wings overview --}}
@if (!empty($content['wings']))
@php
    $wingIcons = [
        'Audit Quality Wing' => 'bi-patch-check',
        'Audit Reforms Wing' => 'bi-arrow-repeat',
        'Performance Audit Wing' => 'bi-graph-up',
        'Capacity Building and IT Wing' => 'bi-laptop',
        'Legal Cell Wing' => 'bi-briefcase',
    ];
@endphp
<section id="wings" class="dga-section dga-section--alt" aria-labelledby="dga-wings-title">
    <div class="container">
        <div class="mb-4 mb-lg-5">
            <span class="dga-section__eyebrow">Organisation</span>
            <h2 id="dga-wings-title" class="dga-section__title">Functional Wings</h2>
            <p class="dga-section__lead">Five major wings coordinating quality, reforms, performance, capacity building, and legal support.</p>
        </div>

        <div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 g-3 g-lg-4">
            @foreach ($content['wings'] as $wing)
                <div class="col">
                    <article class="dga-card dga-wing-card">
                        <span class="dga-wing-card__icon" aria-hidden="true">
                            <i class="bi {{ $wingIcons[$wing['name']] ?? 'bi-layers' }}"></i>
                        </span>
                        <h3>{{ $wing['name'] }}</h3>
                        <p>{{ $wing['detail'] }}</p>
                    </article>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif
