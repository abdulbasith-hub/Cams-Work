{{-- Multi-column responsive footer --}}
<footer class="dga-footer" role="contentinfo">
    <div class="container">
        <div class="row g-4 g-xl-5">
            <div class="col-md-6 col-xl-3">
                <h2 class="dga-footer__title">Director General of Audit</h2>
                <p class="mb-3" style="font-size:0.9rem;">
                    Government of Tamil Nadu — unified supervision for statutory and internal audit departments through CAMS.
                </p>
                <div class="dga-social" aria-label="Social media">
                    <a href="#" aria-label="Facebook (placeholder)"><i class="bi bi-facebook" aria-hidden="true"></i></a>
                    <a href="#" aria-label="X / Twitter (placeholder)"><i class="bi bi-twitter-x" aria-hidden="true"></i></a>
                    <a href="#" aria-label="YouTube (placeholder)"><i class="bi bi-youtube" aria-hidden="true"></i></a>
                    <a href="mailto:cams.dga@tn.gov.in" aria-label="Email DGA office"><i class="bi bi-envelope" aria-hidden="true"></i></a>
                </div>
            </div>

            <div class="col-6 col-md-3 col-xl-2">
                <h3 class="dga-footer__heading">Quick Links</h3>
                <ul class="dga-footer__list">
                    <li><a href="#hero">Home</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#updates">Updates</a></li>
                    <li><a href="#gallery">Gallery</a></li>
                    <li><a href="{{ url('/login') }}">Login</a></li>
                </ul>
            </div>

            <div class="col-6 col-md-3 col-xl-2">
                <h3 class="dga-footer__heading">Citizen Services</h3>
                <ul class="dga-footer__list">
                    <li><a href="#downloads">Downloads</a></li>
                    <li><a href="#announcements">Announcements</a></li>
                    <li><a href="#contact">Helpdesk</a></li>
                    <li><a href="{{ url('screenreader') }}">Screen Reader</a></li>
                </ul>
            </div>

            <div class="col-6 col-md-6 col-xl-2">
                <h3 class="dga-footer__heading">Policies</h3>
                <ul class="dga-footer__list">
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms of Use</a></li>
                    <li><a href="#">Accessibility</a></li>
                    <li><a href="#">Disclaimer</a></li>
                </ul>
            </div>

            <div class="col-6 col-md-6 col-xl-3">
                <h3 class="dga-footer__heading">Contact Information</h3>
                <ul class="dga-footer__list">
                    <li>{{ $content['contact']['address'] ?? 'Nandanam, Chennai - 600 035' }}</li>
                    <li><a href="tel:{{ preg_replace('/\s+/', '', $content['contact']['phone'] ?? '') }}">{{ $content['contact']['phone'] ?? '' }}</a></li>
                    <li><a href="mailto:{{ $content['contact']['email'] ?? 'cams.dga@tn.gov.in' }}">{{ $content['contact']['email'] ?? 'cams.dga@tn.gov.in' }}</a></li>
                </ul>
            </div>
        </div>

        <div class="dga-footer__bottom d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
            <span>&copy; {{ date('Y') }} Director General of Audit, Government of Tamil Nadu. All rights reserved.</span>
            <span>Designed and Developed by NIC</span>
        </div>
    </div>
</footer>

<button type="button" class="dga-back-top" data-dga-back-top aria-label="Back to top">
    <i class="bi bi-arrow-up" aria-hidden="true"></i>
</button>
