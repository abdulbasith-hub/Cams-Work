{{-- Quick Services: 2 / 3 / 4 column responsive cards --}}
<section id="services" class="dga-section dga-section--alt" aria-labelledby="dga-services-title">
    <div class="container">
        <div class="mb-4 mb-lg-5">
            <span class="dga-section__eyebrow">Citizen &amp; Officer Services</span>
            <h2 id="dga-services-title" class="dga-section__title">Quick Services</h2>
            <p class="dga-section__lead">Frequently used pathways into CAMS, directorates, settlements, and support.</p>
        </div>

        <div class="row row-cols-2 row-cols-md-3 row-cols-xl-4 g-3 g-md-4">
            @foreach ($content['services'] ?? [] as $service)
                <div class="col">
                    <a class="dga-card dga-service-card" href="{{ $service['href'] }}">
                        <span class="dga-service-card__icon" aria-hidden="true">
                            <i class="bi {{ $service['icon'] }}"></i>
                        </span>
                        <h3>{{ $service['title'] }}</h3>
                        <p>{{ $service['description'] }}</p>
                    </a>
                </div>
            @endforeach
        </div>
    </div>
</section>
