{{-- Statistics with animated counters --}}
@if (!empty($content['statistics']))
<section id="statistics" class="dga-section dga-section--alt" aria-labelledby="dga-stats-title">
    <div class="container">
        <div class="mb-4 mb-lg-5 text-center mx-auto" style="max-width:40rem;">
            <span class="dga-section__eyebrow">At a Glance</span>
            <h2 id="dga-stats-title" class="dga-section__title">Key Statistics</h2>
            <p class="dga-section__lead mx-auto">A snapshot of the DGA organisational footprint and digital programme.</p>
        </div>

        <div class="row row-cols-2 row-cols-lg-4 g-3 g-lg-4">
            @foreach ($content['statistics'] as $stat)
                <div class="col">
                    <div class="dga-card dga-stat-card">
                        <div class="dga-stat-card__value"
                             data-count="{{ $stat['value'] }}"
                             data-suffix="{{ $stat['suffix'] ?? '' }}">0</div>
                        <p class="dga-stat-card__label">{{ $stat['label'] }}</p>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif
