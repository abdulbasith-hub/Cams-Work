{{-- Latest Updates --}}
@if (!empty($content['updates']))
<section id="updates" class="dga-section" aria-labelledby="dga-updates-title">
    <div class="container">
        <div class="mb-4 mb-lg-5">
            <span class="dga-section__eyebrow">What's New</span>
            <h2 id="dga-updates-title" class="dga-section__title">Latest Updates</h2>
            <p class="dga-section__lead">Official implementation milestones and support notices from the DGA office.</p>
        </div>

        <div class="row row-cols-1 row-cols-md-2 row-cols-xl-4 g-3 g-lg-4">
            @foreach ($content['updates'] as $update)
                <div class="col">
                    <article class="dga-card dga-update-card">
                        <span class="dga-update-card__date">{{ $update['date'] }}</span>
                        <p>{{ $update['text'] }}</p>
                        <a class="btn btn-sm dga-btn-outline align-self-start" href="#announcements">Read More</a>
                    </article>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif
