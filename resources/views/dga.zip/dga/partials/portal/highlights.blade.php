{{-- Department Highlights — image cards --}}
@if (!empty($content['highlights']))
<section id="highlights" class="dga-section" aria-labelledby="dga-highlights-title">
    <div class="container">
        <div class="mb-4 mb-lg-5">
            <span class="dga-section__eyebrow">Priorities</span>
            <h2 id="dga-highlights-title" class="dga-section__title">Department Highlights</h2>
            <p class="dga-section__lead">{{ $content['overview_lead'] ?? 'How the DGA office strengthens audit quality and public accountability.' }}</p>
        </div>

        <div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 g-3 g-lg-4">
            @foreach ($content['highlights'] as $item)
                <div class="col">
                    <article class="dga-card dga-highlight-card">
                        <div class="dga-highlight-card__media">
                            <img src="{{ asset($item['image']) }}"
                                 alt=""
                                 loading="lazy"
                                 decoding="async"
                                 width="640" height="400">
                        </div>
                        <div class="dga-highlight-card__body">
                            <h3>{{ $item['title'] }}</h3>
                            <p>{{ $item['text'] }}</p>
                        </div>
                    </article>
                </div>
            @endforeach
        </div>

        @if (!empty($departments))
            <div class="mt-4 mt-lg-5">
                <h3 class="h5 fw-bold mb-3">Field Directorates</h3>
                <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-5 g-3">
                    @foreach ($departments as $dept)
                        <div class="col">
                            <a class="dga-card dga-service-card text-start align-items-start"
                               href="{{ route('dga.department', $dept['slug']) }}"
                               style="border-top: 0.25rem solid {{ $dept['accent'] ?? '#1e6bb8' }};">
                                <h3 class="mb-1">{{ $dept['short_name'] }}</h3>
                                <p>{{ $dept['name'] }}</p>
                            </a>
                        </div>
                    @endforeach
                </div>
            </div>
        @endif
    </div>
</section>
@endif
